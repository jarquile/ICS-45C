#ifndef CALCULATOR_HPP
#define CALCULATOR_HPP
//#include "Artifacts.hpp"
#include "Student.hpp"

double calculateTotal(double score, double total, double weight);
void calculateFinalGrade(unsigned int number, Artifacts *artifacts, Student* students);

#endif
