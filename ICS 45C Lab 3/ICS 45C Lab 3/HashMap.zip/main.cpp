#include "HashMap.hpp"


int main()
{
	HashMap map;
	
	return 0;
}