#include "Commands.hpp"

Commands::Commands()
	:debugFlag{false}
{
}

void Commands::handleCommands()
{
	std::string line;
	std::string l1, l2, l3;
	do
	{
		std::getline(std::cin, line);
		l1 = line.substr(0, line.find(" "));
		if (l1 == "QUIT")
		{
			std::cout << "GOODBYE" << std::endl;
			return;
		}
		else if (l1 == "CLEAR")
		{
			logins.deleteBucket();
			std::cout << "CLEARED" << std::endl;
			continue;
		}
		line.erase(0, line.find(" ") + 1);
		l2 = line.substr(0, line.find(" "));
		if (l1 == "DEBUG")
		{
			debug(debugFlag,l2);
			continue;
		}
		else if (l1 == "LOGIN" && l2 == "COUNT")
		{
			loginCount();
			continue;
		}
		else if (l1 == "BUCKET" && l2 == "COUNT")
		{
			bucketCount();
			continue;
		}
		else if (l1 == "LOAD" && l2 == "FACTOR")
		{
			loadFactor();
			continue;
		}	
		else if (l1 == "REMOVE" && l2 != "")
		{
			remove(l2);
		}
		//3 Line Commands
		line.erase(0, line.find(" "));
		if (line == "")
		{
			std::cout << "INVALID" << std::endl;
			continue;
		}
		l3 = line.substr(line.rfind(" "), line.length());
		if (l1 == "CREATE" && l2 != " " && l3 != " ")
		{
			create(l2, l3);
		}
		else if (l1 == "LOGIN" && l2 != "" && l3 != "")
		{
			login(l2, l3);
		}
		else if (l1 == "MAX" && l2 == "BUCKET" && l3 == "SIZE")
		{
			maxBucketSize();
		}
	} while (true);
}

void Commands::create(const std::string & username, const std::string & password)
{
	if (logins.contains(username))
	{
		std::cout << "EXISTS" << std::endl;
	}
	else
	{
		logins.add(username, password);
		std::cout << "CREATED" << std::endl;
	}
}

void Commands::login(const std::string & username, const std::string & password)
{
	if (logins.contains(username))
	{
		if (logins.value(username) == password)
			std::cout << "SUCCEEDED" << std::endl;
		else
			std::cout << "FAILED" << std::endl;
	}
	else
		std::cout << "FAILED" << std::endl;
}

void Commands::remove(const std::string & username)
{
	if (!logins.contains(username))
		std::cout << "NONEXISTENT" << std::endl;
	else
	{
		logins.remove(username);
		std::cout << "REMOVED" << std::endl;
	}

}

void Commands::debug(bool & debugFlg, std::string & cmd)
{
	if (cmd == "ON" && debugFlag == true)
		std::cout << "ON ALREADY" << std::endl;
	else if (cmd == "OFF" && debugFlag == false)
		std::cout << "OFF ALREADY" << std::endl;
	else if (cmd == "ON" && debugFlag == false)
	{
		std::cout << "ON NOW" << std::endl;
		debugFlag = true;
	}
	else if (cmd == "OFF" && debugFlag == true)
	{
		std::cout << "OFF NOW" << std::endl;
		debugFlag = false;
	}
}

void Commands::loginCount()
{
	if (debugFlag)
		std::cout << logins.size() << std::endl;
	else
		std::cout << "INVALID" << std::endl;
}

void Commands::bucketCount()
{
	if (debugFlag)
		std::cout << logins.bucketCount() << std::endl;
	else
		std::cout << "INVALID" << std::endl;
}

void Commands::loadFactor()
{
	if (debugFlag)
		std::cout << logins.loadFactor() << std::endl;
	else
		std::cout << "INVALID" << std::endl;
}

void Commands::maxBucketSize()
{
	std::cout << logins.maxBucketSize() << std::endl;
}

