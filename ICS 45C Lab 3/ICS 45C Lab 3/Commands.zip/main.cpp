#include "HashMap.hpp"
#include <iostream>
#include "Commands.hpp"

int main()
{
	Commands Test;
	Test.handleCommands();

	
	return 0;
}